<?php
$con = mysqli_connect("localhost","username","password","db");
?>
